# Mother Engine — firestore.rules audit

Rules received and read in full. Elite Customs section (everything below
the `ELITE CUSTOMS — EXISTING SINGLE-TENANT COLLECTIONS` divider) was
read only to confirm it doesn't intersect any Mother Engine path — it
doesn't (different collection names entirely, `/workers/{workerId}` at
root vs. `/businesses/{businessId}/workers/{workerId}` nested — no
overlap). Not touched, not further audited, per standing instruction.

**Nothing in this document is 🟢 PROVEN.** I have not run anything — no
network in this sandbox, same blocker as last time. Every category below
reflects what's true from reading the rule text and from what the test
suite now covers, not from an execution. Where I'm confident in a reading
of Firestore's own documented rule-engine behavior, I say so and why —
that's still not the same as watching it pass.

## 1. Collection map — everything Mother Engine currently touches

| Path | Purpose |
|---|---|
| `/businesses/{businessId}` | Platform registry: one doc per tenant |
| `/businesses/{businessId}/workers/{workerId}` | Tenant's own worker roster |
| `/businesses/{businessId}/products/{productId}` | Tenant data (the one proven collection) |
| `/platformOperators/{uid}` | Directory of who has operator access (not itself the security mechanism) |

That's the entire footprint. Anything not listed here (a future
`/businesses/{businessId}/orders/{orderId}`, etc.) isn't in the rules
file yet, so Firestore's own default-deny applies to it — that's a
platform guarantee, not something this audit is claiming credit for.

## 2. 🔍 Highest-priority finding — likely breaks product deletion entirely

Found by hand-reading the rule, independent of any test run:

```
match /businesses/{businessId}/products/{productId} {
  allow write: if canAccessTenantData(businessId) &&
    (!('businessId' in request.resource.data) || request.resource.data.businessId == businessId);
}
```

`allow write` covers create + update + delete together. On a **delete**
request, Firestore sets `request.resource` to **null** — there's no new
document. This condition unconditionally reads `request.resource.data` as
part of the AND, with no delete-specific branch. Reading `.data` off null
throws, and a thrown error inside a rules condition makes that condition
false. If that's right, **no one can delete a product right now** — not
the owner, not a worker, not anyone. It fails closed (no boundary opens
up), but it silently kills a real feature the moment anyone tries to use
it in production.

I'm confident in the *mechanism* (this is documented Firestore behavior,
the same footgun the Elite Customs section's own `isActiveAccount()`
comment already describes for a different function). I'm not claiming
proof it's actually broken — only a run confirms that. Both new delete
tests in the suite (`Business A member CAN delete their own product`,
`A WORKER... CAN delete a product`) exist specifically to settle this.
**Run those two first** — they're the highest-signal thing in this whole
batch.

Proposed fix (not applied anywhere, reviewable in
`firestore.rules.PROPOSED-FIX`): split `write` into `create, update`
(which legitimately need `request.resource.data`) and a separate
`delete` that only checks `canAccessTenantData(businessId)`.

**Update — checked against outside sources, since I still can't run this
myself.** Searched for how other Firestore rules authors handle this
exact combined-`write` situation. The recurring, idiomatic guard people
use specifically to survive delete inside a combined `write` rule is to
explicitly OR in a `request.resource == null` check before touching any
field on it — a pattern that only exists, and only shows up repeatedly
across independent examples, because `request.resource` really is null
on delete and any field access off it needs to be guarded for that case.
That's corroboration from how the wider Firestore Rules community writes
around this exact footgun, not a single Google-authored source confirming
it line for line, and it's still not the same as watching your two delete
tests actually run. Confidence is higher than it was; the two tests are
still what settles it for real.

## 3. Design questions the rules answer honestly but that need a decision, not just a test

These aren't bugs — they're real, working-as-written behaviors that are
worth you explicitly signing off on rather than discovering later:

- **No role gating on products at all.** `canAccessTenantData()` checks
  claim + active status only. A `worker` has identical read/write/delete
  power over products as the `owner` — same business, any role, full
  access. May be exactly right for a first tenant collection. Tests
  added (`A WORKER... CAN create/delete a product`) will confirm this is
  the actual behavior; whether it's the *wanted* behavior is yours to
  call.
- **Nobody can read a co-worker's profile — not the owner, not the
  platform operator.** The rule comment calls this deliberate and known.
  Tests added prove it's real (`Business A's OWNER cannot read a
  co-worker's profile`, `platform operator cannot read any worker
  profile`). This means there's currently no way to build a staff roster
  view, worker-management UI, or platform support/oversight screen on
  this data model without a rules change. Flagging exactly like the
  comment asked — as a decision to make when that UI gets built, not a
  surprise.
- **A worker of any role can read the business's own registry entry —
  including `platformFeeRateOverride`.** The registry-read rule only
  checks `hasBusinessClaim`, no role distinction. That means the
  negotiated platform fee rate is visible to every worker in the
  business, not just the owner. Not a cross-tenant leak (same tenant),
  but worth deciding if that's information a rank-and-file worker should
  see.
- **Suspended-business member reading their own worker profile is left
  genuinely open** in the rule text — the registry-doc exemption from
  the active check is explicitly commented as deliberate; the
  `workers/{workerId}` rule reads the same way (claim-only, no active
  check) but has no comment saying that's intentional for this
  collection too. Added as an "OPEN QUESTION" test that logs the actual
  result without asserting pass/fail either way — I'm not going to
  assert a policy call as if it were a bug.

## 4. Coverage matrix — what's tested per collection × operation

| Collection | get/list | create | update | delete | collectionGroup |
|---|---|---|---|---|---|
| `businesses/{id}` | 🟡 own+cross+operator+anon | 🟡 (new) | 🟡 | — (no delete rule; write covers it, untested) | — (not a subcollection) |
| `businesses/{id}/workers/{wid}` | 🟡 self/cross/operator | 🟡 (denied, `if false`) | same as create | same as create | — |
| `businesses/{id}/products/{pid}` | 🟡 own+cross+worker+anon+suspended+ghost-claim | 🟡 forged/honest/missing-field | 🟡 (new) | 🟡 (new) — **see §2** | 🟡 (new) filtered+unfiltered, both directions |
| `platformOperators/{uid}` | 🟡 operator+tenant+anon | 🟡 write denied (new) | same | same | — |

Every cell is 🟡 BUILT BUT NOT VERIFIED. Nothing has run.

## 5. ⚪ BLOCKED BY MISSING EVIDENCE

- **The actual emulator run.** Still no network access in this sandbox —
  same blocker as before, unchanged. Everything in §4 stays 🟡 until you
  run `cd rules-tests && npm install && npm test` locally and bring back
  the real output.
- **Whether the §2 delete bug is real.** My reasoning is solid but
  unexecuted — the two delete tests resolve this, nothing else can.
- **The three design questions in §3.** No test resolves "should this be
  the behavior" — only "is this the behavior." You decide the should.

## 6. 🔴 FAILED

Nothing goes here. I haven't run anything, so I have no observed
failures to report — only a documented, mechanism-level reason to expect
one specific failure (§2) once you do run it.

## 7. What changed in this pass

- Read the real `firestore.rules`, saved unmodified at
  `firestore.rules` in the deliverable.
- Added 14 new test cases targeting the real rule text specifically:
  positive cases that were missing before (operator reading its own
  directory, operator creating a business, same-tenant collectionGroup
  reads succeeding), the two documented-gap proofs (co-worker read
  denial, operator-can't-read-workers), the suspended-registry-read
  proof, the open question on suspended-worker-self-read, the no-role-
  gating proofs, and the list-vs-get distinction on the `businesses`
  collection.
- Found and documented the likely delete bug in §2, with a proposed
  one-block fix in `firestore.rules.PROPOSED-FIX` — not applied anywhere,
  yours to review and verify.
- Corrected one of my own earlier test labels ("owner CAN read their
  workers list" was actually only testing self-read — relabeled for
  accuracy, and added the test that actually checks roster access).

## 8. Your move

Run it. Bring back the real `Tests: X passed, Y total` line, and
specifically which ones failed if any — starting with the two delete
tests in §2. I'll turn whatever comes back into 🟢 or 🔴, fix what's
actually broken, and we keep moving. Elite Customs stays exactly where it
is.
