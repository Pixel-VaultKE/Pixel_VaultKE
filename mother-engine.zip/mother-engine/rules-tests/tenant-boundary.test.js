const fs = require('fs');
const path = require('path');
const {
  initializeTestEnvironment,
  assertSucceeds,
  assertFails
} = require('@firebase/rules-unit-testing');

let testEnv;

const BUS_A = 'BUS_testAAAAAAAA';
const BUS_B = 'BUS_testBBBBBBBB';
const BUS_SUSPENDED = 'BUS_testSUSPENDED';
const BUS_NONEXISTENT = 'BUS_doesNotExist99';

beforeAll(async () => {
  testEnv = await initializeTestEnvironment({
    projectId: 'mother-engine-rules-test',
    firestore: {
      rules: fs.readFileSync(path.resolve(__dirname, '../firestore.rules'), 'utf8')
    }
  });
});

afterAll(async () => {
  await testEnv.cleanup();
});

beforeEach(async () => {
  await testEnv.clearFirestore();
  // Seeded with rules disabled — this is the ONE place in this whole
  // suite where we bypass rules, deliberately, to set up the world the
  // way an admin script would (createBusiness.js, assignUserToBusiness.js
  // both use the Admin SDK, which also bypasses rules). Every actual test
  // below goes through the real rules with no bypass.
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const db = context.firestore();
    await db.collection('businesses').doc(BUS_A).set({ businessId: BUS_A, displayName: 'Business A', slug: 'business-a', status: 'active' });
    await db.collection('businesses').doc(BUS_B).set({ businessId: BUS_B, displayName: 'Business B', slug: 'business-b', status: 'active' });
    await db.collection('businesses').doc(BUS_SUSPENDED).set({ businessId: BUS_SUSPENDED, displayName: 'Suspended Biz', slug: 'suspended-biz', status: 'suspended' });

    await db.collection('businesses').doc(BUS_A).collection('products').doc('prod1')
      .set({ businessId: BUS_A, name: 'Existing A Product', retailPrice: 100 });
    await db.collection('businesses').doc(BUS_B).collection('products').doc('prod1')
      .set({ businessId: BUS_B, name: 'Existing B Product', retailPrice: 150 });

    await db.collection('businesses').doc(BUS_A).collection('workers').doc('alice-uid')
      .set({ userId: 'USR_alice', email: 'alice@a.test', role: 'owner', status: 'active' });
    await db.collection('businesses').doc(BUS_A).collection('workers').doc('carol-uid')
      .set({ userId: 'USR_carol', email: 'carol@a.test', role: 'worker', status: 'active' });

    // Root-level workers/{uid} — this is the ELITE CUSTOMS pattern
    // (isAdminOrOwner() reads this), a completely different collection
    // from businesses/{id}/workers above (the MOTHER ENGINE tenant
    // pattern). uploadApplications' admin review path uses this one.
    await db.collection('workers').doc('admin-uid')
      .set({ role: 'owner', active: true });
    // A genuine admin-role (NOT owner) worker — distinct from admin-uid
    // above, which is actually seeded as 'owner' despite its name. This
    // one exists specifically to test isOwner()-only boundaries, like
    // ownerLog, where an admin account must be denied, not just a
    // random stranger.
    await db.collection('workers').doc('real-admin-uid')
      .set({ role: 'admin', active: true });

    await db.collection('platformOperators').doc('root-uid')
      .set({ email: 'root@platform.test' });
  });
});

function asBusinessA(uid) { return testEnv.authenticatedContext(uid || 'alice-uid', { businessId: BUS_A, role: 'owner', userId: 'USR_alice' }); }
function asBusinessAWorker(uid) { return testEnv.authenticatedContext(uid || 'carol-uid', { businessId: BUS_A, role: 'worker', userId: 'USR_carol' }); }
function asBusinessB(uid) { return testEnv.authenticatedContext(uid || 'bob-uid', { businessId: BUS_B, role: 'owner', userId: 'USR_bob' }); }
function asAdmin(uid) { return testEnv.authenticatedContext(uid || 'admin-uid'); } // Elite Customs' isAdminOrOwner() reads workers/{uid} live, no custom claims needed
function asPlatformOperator(uid) { return testEnv.authenticatedContext(uid || 'root-uid', { platformOperator: true }); }
function asAnonymous() { return testEnv.unauthenticatedContext(); }

describe('Own-tenant access — Business A → A data, Business B → B data', () => {
  test('Business A member CAN read Business A products ✅', async () => {
    await assertSucceeds(
      asBusinessA().firestore().collection('businesses').doc(BUS_A).collection('products').doc('prod1').get()
    );
  });

  test('Business A member CAN write Business A products ✅', async () => {
    await assertSucceeds(
      asBusinessA().firestore().collection('businesses').doc(BUS_A).collection('products').doc('newProd')
        .set({ businessId: BUS_A, name: 'New A Product', retailPrice: 200 })
    );
  });

  test('Business B member CAN read Business B products ✅', async () => {
    await assertSucceeds(
      asBusinessB().firestore().collection('businesses').doc(BUS_B).collection('products').doc('prod1').get()
    );
  });

  test('Business B member CAN write Business B products ✅', async () => {
    await assertSucceeds(
      asBusinessB().firestore().collection('businesses').doc(BUS_B).collection('products').doc('newProd')
        .set({ businessId: BUS_B, name: 'New B Product', retailPrice: 300 })
    );
  });
});

describe('Cross-tenant READ — must be denied both directions', () => {
  test('Business A member CANNOT read Business B products ❌', async () => {
    await assertFails(
      asBusinessA().firestore().collection('businesses').doc(BUS_B).collection('products').doc('prod1').get()
    );
  });

  test('Business B member CANNOT read Business A products ❌', async () => {
    await assertFails(
      asBusinessB().firestore().collection('businesses').doc(BUS_A).collection('products').doc('prod1').get()
    );
  });
});

describe('Cross-tenant WRITE — must be denied both directions', () => {
  test('Business A member CANNOT write into Business B products ❌', async () => {
    await assertFails(
      asBusinessA().firestore().collection('businesses').doc(BUS_B).collection('products').doc('hack')
        .set({ businessId: BUS_B, name: 'Hacked', retailPrice: 1 })
    );
  });

  test('Business B member CANNOT write into Business A products ❌', async () => {
    await assertFails(
      asBusinessB().firestore().collection('businesses').doc(BUS_A).collection('products').doc('hack')
        .set({ businessId: BUS_A, name: 'Hacked', retailPrice: 1 })
    );
  });

  test('Business A member CANNOT overwrite an existing Business B product ❌', async () => {
    await assertFails(
      asBusinessA().firestore().collection('businesses').doc(BUS_B).collection('products').doc('prod1')
        .set({ businessId: BUS_B, name: 'Overwritten', retailPrice: 1 })
    );
  });
});

describe('A worker (not owner) from one tenant tried against another tenant', () => {
  test('A worker-role account from Business A CANNOT read Business B products ❌', async () => {
    await assertFails(
      asBusinessAWorker().firestore().collection('businesses').doc(BUS_B).collection('products').doc('prod1').get()
    );
  });

  test('A worker-role account from Business A CANNOT write Business B products ❌', async () => {
    await assertFails(
      asBusinessAWorker().firestore().collection('businesses').doc(BUS_B).collection('products').doc('hack')
        .set({ businessId: BUS_B, name: 'Hacked', retailPrice: 1 })
    );
  });

  test('A worker-role account CAN still read their own business\'s products ✅ (sanity check — role alone shouldn\'t block same-tenant access)', async () => {
    await assertSucceeds(
      asBusinessAWorker().firestore().collection('businesses').doc(BUS_A).collection('products').doc('prod1').get()
    );
  });
});

describe('Tenant vs. platform console — must never cross', () => {
  test('A tenant member CANNOT read the platform operators directory ❌', async () => {
    await assertFails(
      asBusinessA().firestore().collection('platformOperators').doc('root-uid').get()
    );
  });

  test('A tenant member CANNOT write to their own business\'s registry entry (e.g. change their own fee override) ❌', async () => {
    await assertFails(
      asBusinessA().firestore().collection('businesses').doc(BUS_A).update({ platformFeeRateOverride: 0 })
    );
  });

  test('A tenant member CANNOT read another business\'s registry entry ❌', async () => {
    await assertFails(
      asBusinessA().firestore().collection('businesses').doc(BUS_B).get()
    );
  });

  test('The platform operator CAN read any business\'s registry entry ✅', async () => {
    await assertSucceeds(asPlatformOperator().firestore().collection('businesses').doc(BUS_A).get());
    await assertSucceeds(asPlatformOperator().firestore().collection('businesses').doc(BUS_B).get());
  });

  test('The platform operator alone (no businessId claim) CANNOT read tenant PRODUCT data — by design, not yet granted ❌', async () => {
    // This is deliberate, not an oversight — documented in firestore.rules
    // and in the audit notes. Support/oversight access into live tenant
    // data is a separate decision that hasn't been made yet, so the
    // boundary defaults to closed rather than assuming operators should
    // see everything.
    await assertFails(
      asPlatformOperator().firestore().collection('businesses').doc(BUS_A).collection('products').doc('prod1').get()
    );
  });

  test('The platform operator CAN write to the business registry (e.g. suspend a tenant) ✅', async () => {
    await assertSucceeds(
      asPlatformOperator().firestore().collection('businesses').doc(BUS_A).update({ status: 'suspended' })
    );
  });
});

describe('Unauthenticated access — must be denied everywhere', () => {
  test('Unauthenticated request CANNOT read tenant products ❌', async () => {
    await assertFails(
      asAnonymous().firestore().collection('businesses').doc(BUS_A).collection('products').doc('prod1').get()
    );
  });

  test('Unauthenticated request CANNOT write tenant products ❌', async () => {
    await assertFails(
      asAnonymous().firestore().collection('businesses').doc(BUS_A).collection('products').doc('hack')
        .set({ businessId: BUS_A, name: 'Hacked', retailPrice: 1 })
    );
  });

  test('Unauthenticated request CANNOT read the business registry ❌', async () => {
    await assertFails(asAnonymous().firestore().collection('businesses').doc(BUS_A).get());
  });

  test('Unauthenticated request CANNOT read the platform operators directory ❌', async () => {
    await assertFails(asAnonymous().firestore().collection('platformOperators').doc('root-uid').get());
  });
});

describe('Forged or wrong businessId — the core boundary rule', () => {
  test('A forged businessId FIELD inside the document (path says A, field claims B) is rejected ❌', async () => {
    await assertFails(
      asBusinessA().firestore().collection('businesses').doc(BUS_A).collection('products').doc('forged')
        .set({ businessId: BUS_B, name: 'Forged field', retailPrice: 1 })
    );
  });

  test('A businessId field that matches the path is accepted ✅ (sanity check for the test above)', async () => {
    await assertSucceeds(
      asBusinessA().firestore().collection('businesses').doc(BUS_A).collection('products').doc('honest')
        .set({ businessId: BUS_A, name: 'Honest field', retailPrice: 1 })
    );
  });

  test('Omitting the businessId field entirely is still accepted ✅ (the field is optional, only checked if present)', async () => {
    await assertSucceeds(
      asBusinessA().firestore().collection('businesses').doc(BUS_A).collection('products').doc('noField')
        .set({ name: 'No businessId field at all', retailPrice: 1 })
    );
  });

  test('A user with NO businessId claim at all CANNOT read any tenant products ❌', async () => {
    const noClaim = testEnv.authenticatedContext('dave-uid', {}); // logged in, never assigned to any business
    await assertFails(noClaim.firestore().collection('businesses').doc(BUS_A).collection('products').doc('prod1').get());
  });

  test('A businessId claim pointing at a business that does not exist is denied ❌', async () => {
    const ghost = testEnv.authenticatedContext('ghost-uid', { businessId: BUS_NONEXISTENT, role: 'owner' });
    await assertFails(ghost.firestore().collection('businesses').doc(BUS_NONEXISTENT).collection('products').doc('anything').get());
  });

  test('A businessId claim pointing at a SUSPENDED business is denied immediately, without touching that user\'s claim ❌', async () => {
    const suspendedMember = testEnv.authenticatedContext('suspended-uid', { businessId: BUS_SUSPENDED, role: 'owner' });
    await assertFails(suspendedMember.firestore().collection('businesses').doc(BUS_SUSPENDED).collection('products').doc('anything').get());
  });

  test('Suspending a previously-active business immediately locks out its existing members ❌ (proves businessIsActive() is checked live, not cached)', async () => {
    const aliceBeforeSuspend = asBusinessA();
    await assertSucceeds(aliceBeforeSuspend.firestore().collection('businesses').doc(BUS_A).collection('products').doc('prod1').get());

    await testEnv.withSecurityRulesDisabled(async (context) => {
      await context.firestore().collection('businesses').doc(BUS_A).update({ status: 'suspended' });
    });

    const aliceAfterSuspend = asBusinessA();
    await assertFails(aliceAfterSuspend.firestore().collection('businesses').doc(BUS_A).collection('products').doc('prod1').get());
  });
});

// --- Added on hand-review: the original suite never tested delete, never
// tested a collection-group query (the classic way a per-document
// businessId check gets bypassed if the rule isn't ALSO enforced on
// list/query, not just get), and never touched the `workers` subcollection
// at all. All three are real, common tenant-boundary holes, not
// hypothetical ones — leaving them untested isn't a small gap. -Claude

describe('Delete — untested by the original suite', () => {
  test('Business A member CANNOT delete a Business B product ❌', async () => {
    await assertFails(
      asBusinessA().firestore().collection('businesses').doc(BUS_B).collection('products').doc('prod1').delete()
    );
  });

  test('Business A member CAN delete their own product ✅', async () => {
    await assertSucceeds(
      asBusinessA().firestore().collection('businesses').doc(BUS_A).collection('products').doc('prod1').delete()
    );
  });
});

describe('Update (not just set) — untested by the original suite', () => {
  test('Business A member CANNOT update a Business B product via .update() ❌', async () => {
    await assertFails(
      asBusinessA().firestore().collection('businesses').doc(BUS_B).collection('products').doc('prod1')
        .update({ retailPrice: 1 })
    );
  });
});

describe('Collection-group query — the classic way per-document businessId checks get bypassed', () => {
  test('Business A member running a collectionGroup("products") query gets ONLY Business A documents, never Business B\'s ❌', async () => {
    // A get()-only rule can look airtight while still allowing a
    // collectionGroup query to leak other tenants' docs, because Firestore
    // requires the rule to hold for EVERY document a query could return —
    // if the rule doesn't force a where/path constraint tying the query to
    // the caller's own businessId, an unconstrained collectionGroup read
    // across all businesses gets rejected outright (correct), but a
    // same-collection query for another business's INDEX (e.g.
    // .collectionGroup('products').where('businessId','==',BUS_B)) run by
    // a Business A user must ALSO be rejected. This asserts that case.
    await assertFails(
      asBusinessA().firestore().collectionGroup('products').where('businessId', '==', BUS_B).get()
    );
  });

  test('Business A member running collectionGroup("products") unfiltered is denied, not silently scoped ❌', async () => {
    await assertFails(
      asBusinessA().firestore().collectionGroup('products').get()
    );
  });
});

describe('The workers subcollection — untested by the original suite, despite assignUserToBusiness.js writing to it directly', () => {
  test('A member CAN read their OWN worker profile doc (self-read only — rule is auth.uid == workerId, not a roster read) ✅', async () => {
    await assertSucceeds(
      asBusinessA().firestore().collection('businesses').doc(BUS_A).collection('workers').doc('alice-uid').get()
    );
  });

  test('Business B member CANNOT read a Business A worker\'s profile ❌', async () => {
    await assertFails(
      asBusinessB().firestore().collection('businesses').doc(BUS_A).collection('workers').doc('alice-uid').get()
    );
  });

  test('A worker (not owner) CANNOT write/add a new worker to their own business from the client ❌ (that\'s assignUserToBusiness.js\'s job via the Admin SDK, which bypasses rules — the client should not have this door open at all)', async () => {
    await assertFails(
      asBusinessAWorker().firestore().collection('businesses').doc(BUS_A).collection('workers').doc('new-uid')
        .set({ userId: 'USR_new', email: 'new@a.test', role: 'owner', status: 'active' })
    );
  });

  test('Even a Business A OWNER cannot self-escalate by writing a new worker doc from the client ❌ (same reasoning — this must stay an Admin-SDK-only, server-side operation, not merely a role check)', async () => {
    await assertFails(
      asBusinessA().firestore().collection('businesses').doc(BUS_A).collection('workers').doc('new-uid')
        .set({ userId: 'USR_new', email: 'new@a.test', role: 'owner', status: 'active' })
    );
  });
});

// --- Added after receiving the real firestore.rules text. The rule
// comments themselves flag two things as deliberate: (1) the businesses
// registry read intentionally skips the active-business check so a
// suspended tenant can still see why, and (2) NOBODY — not even that
// business's own owner, not even a platform operator — can read another
// worker's profile; only self-read works. Both are "deliberate" per the
// comment, but a comment isn't proof. These tests turn each claim into
// something that either holds or doesn't once run. -Claude

describe('Documented "known gap": nobody can read a co-worker\'s profile, not even the owner or platform operator', () => {
  test('Business A\'s OWNER (alice) CANNOT read a co-worker\'s (carol\'s) profile in the SAME business ❌ (proves the gap the rule comment describes is real, not theoretical)', async () => {
    await assertFails(
      asBusinessA().firestore().collection('businesses').doc(BUS_A).collection('workers').doc('carol-uid').get()
    );
  });

  test('The platform operator CANNOT read any tenant\'s worker profile either ❌ (the read rule has no isPlatformOperator() branch at all — this isn\'t a tenant-only restriction)', async () => {
    await assertFails(
      asPlatformOperator().firestore().collection('businesses').doc(BUS_A).collection('workers').doc('alice-uid').get()
    );
  });
});

describe('Documented behavior: reading your OWN business registry entry deliberately skips the active-business check', () => {
  test('A member of a SUSPENDED business CAN still read their own business\'s registry doc ✅ (deliberate per the rule comment — "so a suspended tenant can at least see why" — this proves the comment matches the code, not just that it exists)', async () => {
    const suspendedMember = testEnv.authenticatedContext('suspended-uid', { businessId: BUS_SUSPENDED, role: 'owner' });
    await assertSucceeds(
      suspendedMember.firestore().collection('businesses').doc(BUS_SUSPENDED).get()
    );
  });

  // Deliberately NOT asserting either way whether a suspended member can
  // still read their OWN worker profile doc — the workers/{workerId} read
  // rule (hasBusinessClaim only, no businessIsActive check) reads as if it
  // has the same exemption as the registry doc, but nothing in the rules
  // file says that's intentional for workers specifically the way it does
  // for the registry doc. Running this will reveal the actual behavior;
  // whether that behavior is the RIGHT behavior is a product call, not
  // something this test can settle either way.
  test('OPEN QUESTION — does a SUSPENDED business\'s member still read their own worker profile doc? (documents current behavior, does not assert it\'s correct)', async () => {
    const suspendedMember = testEnv.authenticatedContext('suspended-uid', { businessId: BUS_SUSPENDED, role: 'owner' });
    // No assertSucceeds/assertFails on purpose — see comment above. Read
    // the actual pass/fail from the test run and decide if that's wanted.
    try {
      await suspendedMember.firestore().collection('businesses').doc(BUS_SUSPENDED).collection('workers').doc('suspended-uid').get();
      console.log('RESULT: suspended member CAN read their own worker profile — confirm this is intended.');
    } catch (e) {
      console.log('RESULT: suspended member CANNOT read their own worker profile.');
    }
  });
});

describe('platformOperators directory — only negative cases existed before; positive case and write were untested', () => {
  test('The platform operator CAN read the platformOperators directory ✅ (only the denial cases were tested before — never the actual allow)', async () => {
    await assertSucceeds(
      asPlatformOperator().firestore().collection('platformOperators').doc('root-uid').get()
    );
  });

  test('NOBODY can write to platformOperators from the client, not even an operator ❌ (rule is unconditional `allow write: if false` — bootstrapping is admin-scripts/setPlatformOperator.js only)', async () => {
    await assertFails(
      asPlatformOperator().firestore().collection('platformOperators').doc('root-uid')
        .set({ email: 'new@platform.test' })
    );
  });
});

describe('businesses registry — create was untested (original suite only checked update)', () => {
  test('The platform operator CAN create a brand-new business registry entry ✅', async () => {
    await assertSucceeds(
      asPlatformOperator().firestore().collection('businesses').doc('BUS_testNEWBIZ')
        .set({ businessId: 'BUS_testNEWBIZ', displayName: 'New Biz', slug: 'new-biz', status: 'active' })
    );
  });
});

describe('No role gating on products — worth confirming explicitly, not just inferring from canAccessTenantData()\'s definition', () => {
  // canAccessTenantData() checks claim + active status only — no role
  // check anywhere in the products rule. That means a worker has the same
  // products read/write/delete power as the owner. That may well be
  // intentional for a first tenant collection, but it's a real design
  // fact worth having a named, run test for rather than leaving it as
  // something only visible by reading the rule and trusting your own
  // parsing of it.
  test('A WORKER (not owner/admin) in Business A CAN create a product in their own business ✅ (products has no role restriction at all — confirm this is the intended model)', async () => {
    await assertSucceeds(
      asBusinessAWorker().firestore().collection('businesses').doc(BUS_A).collection('products').doc('workerAdded')
        .set({ businessId: BUS_A, name: 'Added by worker', retailPrice: 50 })
    );
  });

  test('A WORKER (not owner/admin) in Business A CAN delete a product in their own business ✅ (same point, for delete)', async () => {
    await assertSucceeds(
      asBusinessAWorker().firestore().collection('businesses').doc(BUS_A).collection('products').doc('prod1').delete()
    );
  });
});

describe('collectionGroup query — the positive case (own-tenant collectionGroup reads should still work, not just be blanket-denied)', () => {
  test('Business A member running collectionGroup("products") filtered to their OWN businessId succeeds ✅ (the earlier collectionGroup tests only proved cross-tenant leakage is blocked — this proves same-tenant collectionGroup reads aren\'t collateral damage)', async () => {
    await assertSucceeds(
      asBusinessA().firestore().collectionGroup('products').where('businessId', '==', BUS_A).get()
    );
  });
});

describe('list vs. get on the businesses collection — untested distinction', () => {
  // Firestore rules require the rule to hold for EVERY document a query
  // could return. hasBusinessClaim(businessId) varies per document, so an
  // unfiltered list/query across the whole `businesses` collection should
  // be impossible for a rule engine to prove safe for a tenant caller —
  // and should be denied outright, not silently scoped to their own doc.
  // isPlatformOperator() is constant across all documents, so the same
  // query should succeed for an operator. This is exactly the kind of
  // list-vs-get gap that bit the earlier collectionGroup analysis —
  // worth proving directly rather than assuming Firestore's query-safety
  // behavior works the way the docs say it does.
  test('A tenant member running an unfiltered list query on the top-level `businesses` collection is denied entirely, not silently scoped to their own doc ❌', async () => {
    await assertFails(
      asBusinessA().firestore().collection('businesses').get()
    );
  });

  test('The platform operator CAN run an unfiltered list query on `businesses` ✅ (isPlatformOperator() holds uniformly per-doc, so this should be provable)', async () => {
    await assertSucceeds(
      asPlatformOperator().firestore().collection('businesses').get()
    );
  });
});

// --- Added when apply.html gained self-edit-while-pending. The whole
// feature rests on one claim: "the anonymous session's uid is the only
// thing that decides whose application this is." These tests exist to
// prove that claim, not assume it — a plain authenticatedContext(uid)
// with no custom claims IS what Firebase Anonymous Auth looks like to
// these rules, so it's the right stand-in here. -Claude

function asApplicant(uid) { return testEnv.authenticatedContext(uid || 'applicant-1'); }

describe('uploadApplications — create requires a matching submitterUid, not just any auth', () => {
  test('An applicant CAN create their own application with submitterUid == their own uid ✅', async () => {
    await assertSucceeds(
      asApplicant('applicant-1').firestore().collection('uploadApplications').add({
        applicantName: 'Test Applicant', phone: '0700000000', email: 'a@test.com',
        whyInterested: 'testing', submitterUid: 'applicant-1', status: 'pending'
      })
    );
  });

  test('An applicant CANNOT create an application claiming to be someone else\'s (forged submitterUid) ❌', async () => {
    await assertFails(
      asApplicant('applicant-1').firestore().collection('uploadApplications').add({
        applicantName: 'Test Applicant', phone: '0700000000', email: 'a@test.com',
        whyInterested: 'testing', submitterUid: 'someone-else-uid', status: 'pending'
      })
    );
  });

  test('An applicant CANNOT create an application pre-marked as approved ❌', async () => {
    await assertFails(
      asApplicant('applicant-1').firestore().collection('uploadApplications').add({
        applicantName: 'Test Applicant', phone: '0700000000', email: 'a@test.com',
        whyInterested: 'testing', submitterUid: 'applicant-1', status: 'approved'
      })
    );
  });

  test('A fully unauthenticated visitor (anonymous auth never established) CANNOT create an application ❌ — this is a real behavior change from before, and depends on Anonymous Authentication being enabled in the Firebase console', async () => {
    await assertFails(
      testEnv.unauthenticatedContext().firestore().collection('uploadApplications').add({
        applicantName: 'Test', phone: '0700000000', email: 'a@test.com',
        whyInterested: 'testing', submitterUid: 'whatever', status: 'pending'
      })
    );
  });
});

describe('uploadApplications — self-edit is scoped to own + pending only', () => {
  async function seedPendingApplication(db, id, submitterUid) {
    await db.collection('uploadApplications').doc(id).set({
      applicantName: 'Original Name', phone: '0700000000', email: 'a@test.com',
      whyInterested: 'testing', submitterUid: submitterUid, status: 'pending'
    });
  }

  test('The original submitter CAN edit their own application while it\'s still pending ✅', async () => {
    const ctx = await testEnv.withSecurityRulesDisabled(async (c) => {
      await seedPendingApplication(c.firestore(), 'app1', 'applicant-1');
    });
    await assertSucceeds(
      asApplicant('applicant-1').firestore().collection('uploadApplications').doc('app1').update({
        applicantName: 'Corrected Name', phone: '0711111111', email: 'a@test.com',
        whyInterested: 'testing', submitterUid: 'applicant-1', status: 'pending'
      })
    );
  });

  test('A DIFFERENT applicant CANNOT edit someone else\'s pending application ❌', async () => {
    await testEnv.withSecurityRulesDisabled(async (c) => {
      await seedPendingApplication(c.firestore(), 'app2', 'applicant-1');
    });
    await assertFails(
      asApplicant('applicant-2').firestore().collection('uploadApplications').doc('app2').update({
        applicantName: 'Hijacked', phone: '0722222222', email: 'a@test.com',
        whyInterested: 'testing', submitterUid: 'applicant-1', status: 'pending'
      })
    );
  });

  test('The original submitter CANNOT use their edit access to change status to approved ❌ (self-approval attempt)', async () => {
    await testEnv.withSecurityRulesDisabled(async (c) => {
      await seedPendingApplication(c.firestore(), 'app3', 'applicant-1');
    });
    await assertFails(
      asApplicant('applicant-1').firestore().collection('uploadApplications').doc('app3').update({
        applicantName: 'Original Name', phone: '0700000000', email: 'a@test.com',
        whyInterested: 'testing', submitterUid: 'applicant-1', status: 'approved'
      })
    );
  });

  test('The original submitter CANNOT edit their application once it\'s already been reviewed ❌ (edit access expires the moment status leaves pending)', async () => {
    await testEnv.withSecurityRulesDisabled(async (c) => {
      await c.firestore().collection('uploadApplications').doc('app4').set({
        applicantName: 'Original Name', phone: '0700000000', email: 'a@test.com',
        whyInterested: 'testing', submitterUid: 'applicant-1', status: 'approved'
      });
    });
    await assertFails(
      asApplicant('applicant-1').firestore().collection('uploadApplications').doc('app4').update({
        applicantName: 'Trying to edit after approval', phone: '0700000000', email: 'a@test.com',
        whyInterested: 'testing', submitterUid: 'applicant-1', status: 'approved'
      })
    );
  });

  test('Even an admin CANNOT change status with a direct client write ❌ — review only happens through reviewApplication() (Admin SDK), which this rules-only test can\'t call directly, but this proves the door it would otherwise use is shut', async () => {
    await testEnv.withSecurityRulesDisabled(async (c) => {
      await seedPendingApplication(c.firestore(), 'app5', 'applicant-1');
    });
    await assertFails(
      asAdmin().firestore().collection('uploadApplications').doc('app5').update({ status: 'rejected' })
    );
  });
});

describe('uploadApplications — read is scoped to own application only', () => {
  test('The submitter CAN read their own application ✅', async () => {
    await testEnv.withSecurityRulesDisabled(async (c) => {
      await c.firestore().collection('uploadApplications').doc('app6').set({
        applicantName: 'X', phone: '0700000000', email: 'a@test.com',
        whyInterested: 'x', submitterUid: 'applicant-1', status: 'pending'
      });
    });
    await assertSucceeds(
      asApplicant('applicant-1').firestore().collection('uploadApplications').doc('app6').get()
    );
  });

  test('A different applicant CANNOT read someone else\'s application ❌', async () => {
    await testEnv.withSecurityRulesDisabled(async (c) => {
      await c.firestore().collection('uploadApplications').doc('app7').set({
        applicantName: 'X', phone: '0700000000', email: 'a@test.com',
        whyInterested: 'x', submitterUid: 'applicant-1', status: 'pending'
      });
    });
    await assertFails(
      asApplicant('applicant-2').firestore().collection('uploadApplications').doc('app7').get()
    );
  });
});

// --- Added with the midnight-boundary fix. The whole feature rests on
// one number: 24 hours. These tests prove the bound is actually where
// the code claims it is, not just described that way in a comment.
// Elite Customs collections (sales/expenses) — root-level, not the
// Mother Engine tenant pattern, so these use plain worker identities.

describe('sales — createdAt can be backdated, but only within a bounded window', () => {
  function saleAt(msAgo) {
    return {
      customerName: 'Test', items: [], amount: 100, amountPaid: 100, balance: 0,
      paymentStatus: 'paid', workerId: 'worker-1',
      createdAt: new Date(Date.now() - msAgo)
    };
  }

  test('A sale timestamped 2 hours ago (a real midnight-correction case) is accepted ✅', async () => {
    await assertSucceeds(
      testEnv.authenticatedContext('worker-1').firestore().collection('sales').add(saleAt(2 * 3600000))
    );
  });

  test('A sale timestamped 25 hours ago is rejected ❌ — past the bound, this is backdating, not a midnight correction', async () => {
    await assertFails(
      testEnv.authenticatedContext('worker-1').firestore().collection('sales').add(saleAt(25 * 3600000))
    );
  });

  test('A sale timestamped in the future is rejected ❌', async () => {
    await assertFails(
      testEnv.authenticatedContext('worker-1').firestore().collection('sales').add(saleAt(-3600000))
    );
  });

  test('A sale with no createdAt field at all is rejected ❌ (the field is now required, not optional)', async () => {
    var data = saleAt(0);
    delete data.createdAt;
    await assertFails(
      testEnv.authenticatedContext('worker-1').firestore().collection('sales').add(data)
    );
  });
});

describe('expenses — same bound, same reasoning', () => {
  test('An expense timestamped 3 hours ago is accepted ✅', async () => {
    await assertSucceeds(
      asAdmin().firestore().collection('expenses').add({
        category: 'Restock', amount: 500, note: '', status: 'approved',
        createdAt: new Date(Date.now() - 3 * 3600000)
      })
    );
  });

  test('An expense timestamped 30 hours ago is rejected ❌', async () => {
    await assertFails(
      asAdmin().firestore().collection('expenses').add({
        category: 'Restock', amount: 500, note: '', status: 'approved',
        createdAt: new Date(Date.now() - 30 * 3600000)
      })
    );
  });
});

describe('ownerLog — the Daily Check-In\'s reminders/notes, OWNER ONLY (not admin)', () => {
  test('Owner CAN create a reminder entry ✅', async () => {
    await assertSucceeds(
      asAdmin().firestore().collection('ownerLog').add({
        type: 'reminder', text: 'Follow up with supplier', status: 'open',
        createdAt: new Date()
      })
    );
  });

  test('A genuine admin-role (not owner) account CANNOT create an ownerLog entry ❌ — this is the actual boundary that matters here', async () => {
    await assertFails(
      testEnv.authenticatedContext('real-admin-uid').firestore().collection('ownerLog').add({
        type: 'note', text: 'Admin trying to use the owner\'s assistant', status: 'open', createdAt: new Date()
      })
    );
  });

  test('A genuine admin-role account CANNOT even read ownerLog ❌', async () => {
    await testEnv.withSecurityRulesDisabled(async (c) => {
      await c.firestore().collection('ownerLog').doc('adminReadTest').set({
        type: 'reminder', text: 'Owner-only content', status: 'open', createdAt: new Date()
      });
    });
    await assertFails(
      testEnv.authenticatedContext('real-admin-uid').firestore().collection('ownerLog').doc('adminReadTest').get()
    );
  });

  test('A plain worker (not admin, not owner) CANNOT create an ownerLog entry ❌', async () => {
    await assertFails(
      testEnv.authenticatedContext('some-worker-uid').firestore().collection('ownerLog').add({
        type: 'note', text: 'Trying to sneak one in', status: 'open', createdAt: new Date()
      })
    );
  });

  test('An entry with an invalid type is rejected ❌ (only reminder/note allowed — task-type never lands here)', async () => {
    await assertFails(
      asAdmin().firestore().collection('ownerLog').add({
        type: 'task', text: 'Should not be allowed here', status: 'open', createdAt: new Date()
      })
    );
  });

  test('Marking an entry done (status only) succeeds ✅', async () => {
    await testEnv.withSecurityRulesDisabled(async (c) => {
      await c.firestore().collection('ownerLog').doc('entry1').set({
        type: 'reminder', text: 'Original text', status: 'open', createdAt: new Date()
      });
    });
    await assertSucceeds(
      asAdmin().firestore().collection('ownerLog').doc('entry1').update({ status: 'done' })
    );
  });

  test('Changing the text of an existing entry is rejected ❌ (update is status-only by design)', async () => {
    await testEnv.withSecurityRulesDisabled(async (c) => {
      await c.firestore().collection('ownerLog').doc('entry2').set({
        type: 'reminder', text: 'Original text', status: 'open', createdAt: new Date()
      });
    });
    await assertFails(
      asAdmin().firestore().collection('ownerLog').doc('entry2').update({ text: 'Rewritten after the fact', status: 'open' })
    );
  });
});
