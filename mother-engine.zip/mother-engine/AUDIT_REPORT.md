# Mother Engine — Step 02 audit report

## 1. What I actually did tonight

- Inspected everything uploaded: `createBusiness.js`, `assignUserToBusiness.js`,
  `ids.js`, `tenant-boundary_test.js`, `firebase.json`, `package.json`,
  `README.md`, plus `admin.html`, `customer.html`, `worker.html`, `index.js`.
- Confirmed the last four are **Elite Customs**, not Mother Engine (they
  reference "Elite Customs" by name and use root-level `orders`/`products`
  collections, not the `businesses/{id}/...` tenant pattern). Left them
  completely untouched, per your instruction.
- Rebuilt the correct directory layout so the scripts' own `require()`
  calls resolve (`scripts/lib/ids.js`, `scripts/lib/firebaseAdmin.js`,
  `scripts/createBusiness.js`, `scripts/assignUserToBusiness.js`,
  `rules-tests/tenant-boundary.test.js`).
- Hand-reviewed `createBusiness.js` and `assignUserToBusiness.js` line by
  line for logic and security issues (findings below).
- Extended the test suite with cases the original one didn't cover:
  delete, `.update()`, collection-group query leakage, and the `workers`
  subcollection. Details below.

## 2. Two real blockers — stated plainly, not glossed over

**`firestore.rules` itself was never uploaded.** It's not in this upload
set anywhere. The test file, `firebase.json`, and the README all reference
it as the file one level up from `rules-tests/`, but I don't have it. I
have **not** audited your Firestore rules, because I don't have them to
read. Anything I say about the rules below is inference from the tests
that target them, not a review of the rules themselves. If you want the
actual rules audited — the thing you asked for in step 2 — I need that
file.

**This sandbox has no network access.** Even with `firestore.rules` in
hand, I can't run `npm install`, download the Firestore emulator, or
execute `npm test` here. That's not a policy choice, it's the environment.
So "finish the emulator test setup" (step 4) is done in the sense that the
test file, directory layout, and missing `require()` target are now
correct and should actually run — but "prove tenant isolation" (the
actual goal) still requires you to run it locally, same as the README
already told you last time. I'm not going to claim green checkmarks I
never produced.

## 3. Bug fixed: broken `require()` paths

`createBusiness.js` and `assignUserToBusiness.js` both do:
```js
require('./lib/firebaseAdmin')
require('./lib/ids')
```
but `ids.js` was uploaded flat, not under `lib/`, and `lib/firebaseAdmin.js`
didn't exist at all. Neither script could have run as uploaded. Fixed by:
- Moving `ids.js` → `scripts/lib/ids.js` (content unchanged).
- Writing `scripts/lib/firebaseAdmin.js` new, using the standard
  Application Default Credentials pattern. **This is new code I wrote to
  fill a real gap, not something recovered from your files — verify it
  matches how you actually authenticate (ADC vs. a service account key
  path vs. something else) before trusting it.**

## 4. Hand-audit findings on the admin scripts

Both are Admin-SDK CLI tools run by a trusted operator locally — they
bypass Firestore rules entirely, so their risk profile is "could this
script itself do the wrong thing," not "could an attacker call this."

- **`createBusiness.js`** — slug-uniqueness check-then-write has a TOCTOU
  race if run twice concurrently for the same slug (unlikely for a
  single-operator CLI tool, but a `businesses` collection could use the
  slug as part of a transaction or a separate slug-registry doc with a
  create-only write if you want it airtight). No input validation on
  `--name` beyond presence, which is fine for a trusted local tool.
- **`assignUserToBusiness.js`** — logic is sound: single-membership
  invariant is enforced, the previous business's worker doc is correctly
  marked `removed` rather than deleted, the `--force` gate on inactive
  businesses is a sensible hard-stop-by-default. No issues found.
- **`ids.js`** — 12 random bytes over a 55-character alphabet is ~68.7
  bits of entropy, appropriately treated as a non-secret identifier, not a
  capability token. No issues.

## 5. Test suite: gaps found and closed (pending an actual run)

The original `tenant-boundary_test.js` was thorough on read/write/get
across the core scenarios, but had three real, common holes — not
nitpicks:

1. **No delete or `.update()` tests.** Only `.get()` and `.set()` were
   exercised. A rule that correctly blocks `set` can still leave `delete`
   or `update` open if it wasn't written to cover all write types.
2. **No collection-group query test.** This is the classic way a
   per-document `businessId` check gets bypassed: a rule that looks
   airtight for `get()` can still let a `collectionGroup('products')`
   query — filtered or not — return other tenants' documents if the rule
   doesn't force every possible query result to satisfy the same check.
   Added both a filtered (`where businessId == BUS_B`) and unfiltered
   version, both asserted as denied for a Business A caller.
3. **The `workers` subcollection was never touched.** `assignUserToBusiness.js`
   writes there directly via the Admin SDK, but nothing tested what the
   *client-facing* rule allows. I added tests asserting: same-business
   owner can read it, other businesses can't read it, and — this is a
   policy assertion, not a certainty — that no client (not even an owner)
   can write a new worker doc from the client SDK at all, since that's
   supposed to stay an Admin-SDK-only operation per how
   `assignUserToBusiness.js` is designed. **If your rules don't yet
   enforce that, these two tests will legitimately fail and that's a real
   hole, not a test bug — decide if that's the policy you want before
   you flip it.**

All of this is written and in place. None of it has been run. I'm not
telling you it passed.

## 6. What still needs real emulator verification (your move)

Everything. Every single test in this suite — old and new — is unverified
until you run:
```
cd rules-tests && npm install && npm test
```
locally, with your real `firestore.rules` one directory up. Come back with
the actual output (pass/fail counts, and specifically which `assertFails`
tests failed if any) and I'll fix whatever the rules got wrong. If you
paste or upload `firestore.rules` itself, I can also do the actual rules
read you originally asked for instead of inferring its behavior secondhand
through tests.

## 7. Elite Customs

Untouched. `admin.html`, `customer.html`, `worker.html`, `index.js` were
not read for anything beyond confirming they're Elite Customs and out of
scope. Nothing here required touching them.
